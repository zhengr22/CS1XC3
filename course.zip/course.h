/**
  * @file     	course.h
  * @date    	13-04-2022
  * @brief   	course
  * @attention
  */  
#include "student.h"
#include <stdbool.h>

/**
 * @brief course strcut info, include name,code,students pointer and total number
 *
 * @details the course structure, store course info
 */
typedef struct _course 
{
  char name[100];	/**< name. */
  
  char code[10];  /**< code. */
  
  Student *students;	/**< student pointer. */
  
  int total_students; /**< student size. */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


