/**
  * @file     	course.c
  * @date    	12-03-2022
  * @brief   	course information
  * @attention
  */  

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * enroll student, 
 * course : course manager pointer
 * student : student pointer
 *
 * not return
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
      //calloc memory
    course->students = calloc(1, sizeof(Student));
  }
  else 
  //realloc memory has been used
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 *
 * print course info and student info, using printf
 * ourse : course manager pointer
 * for loop to print every student info
 * no return
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * find the students who have the best grades
 * course : course manager pointer
 * return :
 * the students who have the best grades
 */
Student* top_student(Course* course)
{
  /// if the number of student is 0 return NULL
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }
  
  /// find it, return student pointer
  return student;
}

/**
 * Count the number of student passes, return the students who pass
 * course : course manager pointer
 * total_passing: passing number, using int*
 *	return the students who pass, return student*
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  /// calc average grades
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  
  *total_passing = count;
    /// count the total number of student
  return passing;
}