/**
  * @file     	student.h
  * @date    	13-04-2022
  * @brief   	student declaration
  * @attention
  */   
  

/**
 * @brief student  info
 *
 * @details Describe the student  structure
 */
typedef struct _student 
{ 
  char first_name[50];/**< first name. */
  
  char last_name[50];/**< last name. */
  
  char id[11];/**< id. */
  
  double *grades; /**< grades pointer. */
  
  int num_grades; /**< num grades. */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
